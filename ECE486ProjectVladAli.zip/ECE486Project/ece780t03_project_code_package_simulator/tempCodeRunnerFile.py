
    plt.axis('equal')